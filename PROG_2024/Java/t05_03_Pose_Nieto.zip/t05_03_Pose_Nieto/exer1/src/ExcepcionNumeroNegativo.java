public class ExcepcionNumeroNegativo extends Exception{
    
    public ExcepcionNumeroNegativo(String message){
        super(message);
    }

}
