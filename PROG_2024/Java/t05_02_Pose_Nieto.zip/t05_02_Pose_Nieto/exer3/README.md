# Exercicio 3
## Modifica o exercicio 2, da tarefa T05_01 para que:

1. A clase Deportista implante a interface Comparable, na que se utilizará como criterio de ordenación a data de nacemento.

1. No programa principal, os deportistas débense mostrar ordenados polo criterio de ordenación da clase Deportista.

1. No programa principal, os tenistas débense ordenar polo seu número de ranking.

1. No programa principal, tanto os pilotos como os pilotos de F1 débense ordenar por puntos de maior a menor. En cambio, os pilotos de MotoGP deberán estar ordenados de forma inversa.