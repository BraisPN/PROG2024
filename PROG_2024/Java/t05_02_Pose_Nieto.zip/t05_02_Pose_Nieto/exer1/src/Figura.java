public interface Figura {

    double calcularArea();
}