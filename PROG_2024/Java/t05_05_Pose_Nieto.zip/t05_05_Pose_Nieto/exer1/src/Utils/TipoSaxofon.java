package Utils;

public enum TipoSaxofon {
    SOPRANO,ALTO,TENOR,BARITONO
}
