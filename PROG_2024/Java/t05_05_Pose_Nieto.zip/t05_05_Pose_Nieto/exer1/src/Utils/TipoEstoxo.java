package Utils;

public enum TipoEstoxo {
    FRAUTA, SAXOFON, TROMBON
}
