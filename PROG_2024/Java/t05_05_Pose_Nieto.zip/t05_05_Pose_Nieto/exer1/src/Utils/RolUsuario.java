package Utils;

public enum RolUsuario {
    ADMINISTRADOR, CLIENTE
}
