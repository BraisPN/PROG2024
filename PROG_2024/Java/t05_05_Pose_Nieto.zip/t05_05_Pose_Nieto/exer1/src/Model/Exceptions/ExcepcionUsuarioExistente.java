package Model.Exceptions;

public class ExcepcionUsuarioExistente extends Exception {

    public ExcepcionUsuarioExistente(String message) {
        super(message);
    }
}