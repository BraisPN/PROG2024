package Model.Exceptions;

public class ExcepcionEliminarStockInexistente extends Exception {

    public ExcepcionEliminarStockInexistente(String message) {
        super(message);
    }
}