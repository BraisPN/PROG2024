package Model.Exceptions;

public class ExcepcionComprarSenStock extends Exception {

    public ExcepcionComprarSenStock(String message) {
        super(message);
    }
}