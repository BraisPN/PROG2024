package Model.Exceptions;

public class ExcepcionIdInvalido extends Exception {

    public ExcepcionIdInvalido(String message) {
        super(message);
    }
}