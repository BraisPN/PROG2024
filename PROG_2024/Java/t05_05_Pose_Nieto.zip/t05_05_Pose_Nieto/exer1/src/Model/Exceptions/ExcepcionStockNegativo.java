package Model.Exceptions;

public class ExcepcionStockNegativo extends Exception {

    public ExcepcionStockNegativo(String message) {
        super(message);
    }
}