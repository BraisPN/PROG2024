package Model.Exceptions;

public class ExcepcionPrezoNegativo extends Exception {

    public ExcepcionPrezoNegativo(String message) {
        super(message);
    }
}